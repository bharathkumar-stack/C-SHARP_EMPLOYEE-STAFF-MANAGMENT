﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Configuration;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeStaffApplication
{
    public partial class EmployeeDisplay : Form
    {
        SqlConnection conn;
        public EmployeeDisplay()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["emp"].ConnectionString);
        }

        private void EmployeeDisplay_Load(object sender, EventArgs e)
        {
            try
            {
                List<EmpPoco> l = new List<EmpPoco>();
                conn.Open();
                string sql = "Select * from EmployeeDetails";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    EmpPoco emp = new EmpPoco();
                    emp.EmpId = Convert.ToInt32(reader[0].ToString());
                    emp.EmpName = reader[1].ToString();
                    emp.EmpPhone = reader[2].ToString();
                    emp.EmpGender = reader[3].ToString();
                    emp.EmpPosition = reader[4].ToString();
                    emp.EmpEducation = reader[5].ToString();
                    emp.EmpDob = reader[6].ToString();
                    emp.EmpAddress = reader[7].ToString();
                    emp.EmpLocation = reader[8].ToString();
                    emp.EmpPass = "**********";
                    l.Add(emp);
                }
                empgridview.DataSource = l;
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }

        private void empgridview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            EmployeeInsert i = new EmployeeInsert();
            i.Show();
            this.Hide();
        }

        private void btnfront_Click(object sender, EventArgs e)
        {
            EmployeeSearch s = new EmployeeSearch();
            s.Show();
            this.Hide();
        }
    }
}
