﻿namespace EmployeeStaffApplication
{
    partial class EmpInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmpInterface));
            this.btnpayslip = new System.Windows.Forms.Button();
            this.btndetails = new System.Windows.Forms.Button();
            this.btnlogout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnpayslip
            // 
            this.btnpayslip.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnpayslip.BackgroundImage")));
            this.btnpayslip.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnpayslip.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnpayslip.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpayslip.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnpayslip.Location = new System.Drawing.Point(682, 254);
            this.btnpayslip.Name = "btnpayslip";
            this.btnpayslip.Size = new System.Drawing.Size(295, 125);
            this.btnpayslip.TabIndex = 1;
            this.btnpayslip.Text = "My payslip";
            this.btnpayslip.UseVisualStyleBackColor = true;
            this.btnpayslip.Click += new System.EventHandler(this.btnpayslip_Click);
            // 
            // btndetails
            // 
            this.btndetails.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btndetails.BackgroundImage")));
            this.btndetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btndetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndetails.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndetails.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btndetails.Location = new System.Drawing.Point(216, 254);
            this.btndetails.Name = "btndetails";
            this.btndetails.Size = new System.Drawing.Size(295, 125);
            this.btndetails.TabIndex = 1;
            this.btndetails.Text = "My Details";
            this.btndetails.UseVisualStyleBackColor = true;
            this.btndetails.Click += new System.EventHandler(this.btndetails_Click);
            // 
            // btnlogout
            // 
            this.btnlogout.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnlogout.BackgroundImage")));
            this.btnlogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlogout.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnlogout.Location = new System.Drawing.Point(1093, 506);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.Size = new System.Drawing.Size(124, 64);
            this.btnlogout.TabIndex = 2;
            this.btnlogout.Text = "Log Out";
            this.btnlogout.UseVisualStyleBackColor = true;
            this.btnlogout.Click += new System.EventHandler(this.btnlogout_Click);
            // 
            // EmpInterface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1272, 602);
            this.Controls.Add(this.btnlogout);
            this.Controls.Add(this.btndetails);
            this.Controls.Add(this.btnpayslip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EmpInterface";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EmpInterface";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnpayslip;
        private System.Windows.Forms.Button btndetails;
        private System.Windows.Forms.Button btnlogout;
    }
}