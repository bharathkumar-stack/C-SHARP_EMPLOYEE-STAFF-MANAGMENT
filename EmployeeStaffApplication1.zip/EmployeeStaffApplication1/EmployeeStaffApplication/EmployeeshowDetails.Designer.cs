﻿namespace EmployeeStaffApplication
{
    partial class EmployeeshowDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeshowDetails));
            this.btnback = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.lbllocation = new System.Windows.Forms.Label();
            this.lbladdress = new System.Windows.Forms.Label();
            this.lbldob = new System.Windows.Forms.Label();
            this.lbleducation = new System.Windows.Forms.Label();
            this.lblpos = new System.Windows.Forms.Label();
            this.lblgender = new System.Windows.Forms.Label();
            this.lblphone = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.panelemployee = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblname1 = new System.Windows.Forms.Label();
            this.panelemployee.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnback
            // 
            this.btnback.Location = new System.Drawing.Point(2, 4);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(75, 23);
            this.btnback.TabIndex = 42;
            this.btnback.Text = "<-";
            this.btnback.UseVisualStyleBackColor = true;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Red;
            this.btnexit.Location = new System.Drawing.Point(1230, 1);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(43, 39);
            this.btnexit.TabIndex = 40;
            this.btnexit.Text = "X";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // lbllocation
            // 
            this.lbllocation.AutoSize = true;
            this.lbllocation.Location = new System.Drawing.Point(798, 299);
            this.lbllocation.Name = "lbllocation";
            this.lbllocation.Size = new System.Drawing.Size(54, 17);
            this.lbllocation.TabIndex = 5;
            this.lbllocation.Text = "label19";
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.Location = new System.Drawing.Point(798, 224);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.Size = new System.Drawing.Size(54, 17);
            this.lbladdress.TabIndex = 5;
            this.lbladdress.Text = "label19";
            // 
            // lbldob
            // 
            this.lbldob.AutoSize = true;
            this.lbldob.Location = new System.Drawing.Point(798, 147);
            this.lbldob.Name = "lbldob";
            this.lbldob.Size = new System.Drawing.Size(54, 17);
            this.lbldob.TabIndex = 5;
            this.lbldob.Text = "label19";
            // 
            // lbleducation
            // 
            this.lbleducation.AutoSize = true;
            this.lbleducation.Location = new System.Drawing.Point(798, 60);
            this.lbleducation.Name = "lbleducation";
            this.lbleducation.Size = new System.Drawing.Size(54, 17);
            this.lbleducation.TabIndex = 5;
            this.lbleducation.Text = "label19";
            // 
            // lblpos
            // 
            this.lblpos.AutoSize = true;
            this.lblpos.Location = new System.Drawing.Point(324, 287);
            this.lblpos.Name = "lblpos";
            this.lblpos.Size = new System.Drawing.Size(54, 17);
            this.lblpos.TabIndex = 5;
            this.lblpos.Text = "label19";
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.Location = new System.Drawing.Point(324, 224);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(54, 17);
            this.lblgender.TabIndex = 5;
            this.lblgender.Text = "label19";
            // 
            // lblphone
            // 
            this.lblphone.AutoSize = true;
            this.lblphone.Location = new System.Drawing.Point(324, 147);
            this.lblphone.Name = "lblphone";
            this.lblphone.Size = new System.Drawing.Size(54, 17);
            this.lblphone.TabIndex = 5;
            this.lblphone.Text = "label19";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(324, 60);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(54, 17);
            this.lblname.TabIndex = 5;
            this.lblname.Text = "label19";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(599, 299);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(62, 17);
            this.label11.TabIndex = 4;
            this.label11.Text = "Location";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(130, 287);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(83, 17);
            this.label12.TabIndex = 4;
            this.label12.Text = "Designation";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(599, 224);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 17);
            this.label13.TabIndex = 4;
            this.label13.Text = "Address";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(599, 147);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(90, 17);
            this.label14.TabIndex = 4;
            this.label14.Text = "Date Of Birth";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(130, 224);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 17);
            this.label15.TabIndex = 4;
            this.label15.Text = "Gender";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(599, 60);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 17);
            this.label16.TabIndex = 4;
            this.label16.Text = "Education";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(130, 147);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(103, 17);
            this.label17.TabIndex = 4;
            this.label17.Text = "Phone Number";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(130, 60);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(45, 17);
            this.label18.TabIndex = 4;
            this.label18.Text = "Name";
            // 
            // panelemployee
            // 
            this.panelemployee.Controls.Add(this.lbllocation);
            this.panelemployee.Controls.Add(this.lbladdress);
            this.panelemployee.Controls.Add(this.lbldob);
            this.panelemployee.Controls.Add(this.lbleducation);
            this.panelemployee.Controls.Add(this.lblpos);
            this.panelemployee.Controls.Add(this.lblgender);
            this.panelemployee.Controls.Add(this.lblphone);
            this.panelemployee.Controls.Add(this.lblname);
            this.panelemployee.Controls.Add(this.label11);
            this.panelemployee.Controls.Add(this.label12);
            this.panelemployee.Controls.Add(this.label13);
            this.panelemployee.Controls.Add(this.label14);
            this.panelemployee.Controls.Add(this.label15);
            this.panelemployee.Controls.Add(this.label16);
            this.panelemployee.Controls.Add(this.label17);
            this.panelemployee.Controls.Add(this.label18);
            this.panelemployee.Location = new System.Drawing.Point(73, 198);
            this.panelemployee.Name = "panelemployee";
            this.panelemployee.Size = new System.Drawing.Size(1022, 376);
            this.panelemployee.TabIndex = 39;
            this.panelemployee.Paint += new System.Windows.Forms.PaintEventHandler(this.panelemployee_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label1.Location = new System.Drawing.Point(366, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(308, 38);
            this.label1.TabIndex = 36;
            this.label1.Text = "Welcome To Virtusa";
            // 
            // lblname1
            // 
            this.lblname1.AutoSize = true;
            this.lblname1.BackColor = System.Drawing.Color.Transparent;
            this.lblname1.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname1.ForeColor = System.Drawing.Color.Transparent;
            this.lblname1.Location = new System.Drawing.Point(720, 76);
            this.lblname1.Name = "lblname1";
            this.lblname1.Size = new System.Drawing.Size(174, 38);
            this.lblname1.TabIndex = 5;
            this.lblname1.Text = "EmpName";
            // 
            // EmployeeshowDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1272, 602);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.panelemployee);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblname1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EmployeeshowDetails";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EmployeeshowDetails";
            this.Load += new System.EventHandler(this.EmployeeshowDetails_Load);
            this.panelemployee.ResumeLayout(false);
            this.panelemployee.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Label lbllocation;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Label lbldob;
        private System.Windows.Forms.Label lbleducation;
        private System.Windows.Forms.Label lblpos;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.Label lblphone;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panelemployee;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblname1;
    }
}