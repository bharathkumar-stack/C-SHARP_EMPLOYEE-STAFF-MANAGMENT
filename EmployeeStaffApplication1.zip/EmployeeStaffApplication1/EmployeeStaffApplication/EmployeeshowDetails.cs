﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace EmployeeStaffApplication
{
    public partial class EmployeeshowDetails : Form
    {
        SqlConnection conn;
        public EmployeeshowDetails()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["emp"].ConnectionString);
        }

        private void EmployeeshowDetails_Load(object sender, EventArgs e)
        {
                SetterClass s = new SetterClass();
               
                EmpPoco p = new EmpPoco();
                p = s.GetEmployeeDetails();
               
                lblname1.Text = p.EmpName;
                lblname.Text = p.EmpName;
                    lblphone.Text = p.EmpPhone;
                lblgender.Text = p.EmpGender;
                lblpos.Text = p.EmpPosition;
                lbleducation.Text = p.EmpEducation;
                lbldob.Text = p.EmpDob;
                lbladdress.Text = p.EmpAddress;
                    lbllocation.Text = p.EmpLocation;
                    panelemployee.Visible = true;
        }

        private void panelemployee_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnback_Click(object sender, EventArgs e)
        {
            EmpInterface f = new EmpInterface();
            f.Show();
            this.Hide();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
