﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeStaffApplication
{
    public class SetterClass
    {
        SqlConnection conn=new SqlConnection(ConfigurationManager.ConnectionStrings["emp"].ConnectionString);
        public EmpPoco GetEmployeeDetails( )
        {
            try
            {
                EmpPoco emp = new EmpPoco();
                conn.Open();
                string sql = "select * from EmployeeDetails where EmpId='" + EmployeeLogin.empid + "'";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    emp.EmpId = Convert.ToInt32(reader[0].ToString());
                    emp.EmpName = reader[1].ToString();
                    emp.EmpPhone = reader[2].ToString();
                    emp.EmpGender = reader[3].ToString();
                    emp.EmpPosition = reader[4].ToString();
                    emp.EmpEducation = reader[5].ToString();
                    emp.EmpDob = reader[6].ToString();
                    emp.EmpAddress = reader[7].ToString();
                    emp.EmpLocation = reader[8].ToString();
                    emp.EmpPass = "**********";
                }
                return emp;
            }
            catch (Exception ob)
            {
                return null;
            }
           
        }
    }
}
