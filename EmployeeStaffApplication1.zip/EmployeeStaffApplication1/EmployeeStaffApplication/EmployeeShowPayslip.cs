﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeStaffApplication
{
    public partial class EmployeeShowPayslip : Form
    {
        SqlConnection conn;
        public EmployeeShowPayslip()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["emp"].ConnectionString);
        }

        private void EmployeeShowPayslip_Load(object sender, EventArgs e)
        {

        }

        private void panelemployee_Paint(object sender, PaintEventArgs e)
        {
            SetterClass s = new SetterClass();
            EmpPoco q = new EmpPoco();
            q = s.GetEmployeeDetails();
            lblid.Text = EmployeeLogin.empid;
            lblname.Text = q.EmpName;
            try
            {
                conn.Open();
                string sql1 = "Select * from EmpPayslip where Payslipid='" +EmployeeLogin.empid+"'";
                SqlCommand cmd1 = new SqlCommand(sql1, conn);
                SqlDataReader reader1 = cmd1.ExecuteReader();
                if (reader1.Read())
                {
                    PaySlipPoco p = new PaySlipPoco();
                    p.Payslipid = int.Parse(reader1[0].ToString());
                    p.TotalWorkingDays = int.Parse(reader1[1].ToString());
                    p.EmpWorkingDays = int.Parse(reader1[2].ToString());
                    p.EmpLeaves = int.Parse(reader1[3].ToString());
                    p.ProvidentFund = int.Parse(reader1[4].ToString());
                    p.SalDeductions = int.Parse(reader1[5].ToString());
                    p.TotalSalary = int.Parse(reader1[6].ToString());

                    lblpayid.Text = reader1[0].ToString();
                    lbltwd.Text = reader1[1].ToString();
                    lblewd.Text = reader1[2].ToString();
                    lblleaves.Text = reader1[3].ToString();
                    lblpf.Text = reader1[4].ToString();
                    lblsaldeduc.Text = reader1[5].ToString();
                    lbltotlasal.Text = reader1[6].ToString();
                    panelemployee.Visible = true;

                }
                else
                {
                    MessageBox.Show("Payslip is not present.");
                }
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
            conn.Close();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            EmpInterface f = new EmpInterface();
            f.Show();
            this.Hide();
        }
    }
}
