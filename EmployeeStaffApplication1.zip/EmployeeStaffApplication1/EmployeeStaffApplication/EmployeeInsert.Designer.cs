﻿namespace EmployeeStaffApplication
{
    partial class EmployeeInsert
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeInsert));
            this.lblempid = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtphone = new System.Windows.Forms.TextBox();
            this.txtempname = new System.Windows.Forms.TextBox();
            this.comgen = new System.Windows.Forms.ComboBox();
            this.emppos = new System.Windows.Forms.ComboBox();
            this.empeducation = new System.Windows.Forms.ComboBox();
            this.dateTimePickerdob = new System.Windows.Forms.DateTimePicker();
            this.empaddress = new System.Windows.Forms.TextBox();
            this.emplocation = new System.Windows.Forms.ComboBox();
            this.btninsert = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.txtpass = new System.Windows.Forms.TextBox();
            this.btnexit = new System.Windows.Forms.Button();
            this.btnback = new System.Windows.Forms.Button();
            this.btnfront = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblempid
            // 
            this.lblempid.AutoSize = true;
            this.lblempid.BackColor = System.Drawing.Color.White;
            this.lblempid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblempid.ForeColor = System.Drawing.Color.Black;
            this.lblempid.Location = new System.Drawing.Point(156, 110);
            this.lblempid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblempid.Name = "lblempid";
            this.lblempid.Size = new System.Drawing.Size(100, 20);
            this.lblempid.TabIndex = 0;
            this.lblempid.Text = "Employee Id";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(156, 245);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(383, 245);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Phone Number";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(675, 110);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "Gender";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(675, 245);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "Designation";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(156, 391);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 20);
            this.label6.TabIndex = 1;
            this.label6.Text = "Education";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(383, 391);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 20);
            this.label7.TabIndex = 1;
            this.label7.Text = "Date Of Birth";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(928, 291);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(149, 20);
            this.label8.TabIndex = 1;
            this.label8.Text = "Employee Address";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(675, 391);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 20);
            this.label9.TabIndex = 1;
            this.label9.Text = "Job Location";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // txtphone
            // 
            this.txtphone.Location = new System.Drawing.Point(387, 300);
            this.txtphone.Margin = new System.Windows.Forms.Padding(4);
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(175, 27);
            this.txtphone.TabIndex = 3;
            // 
            // txtempname
            // 
            this.txtempname.Location = new System.Drawing.Point(160, 301);
            this.txtempname.Margin = new System.Windows.Forms.Padding(4);
            this.txtempname.Name = "txtempname";
            this.txtempname.Size = new System.Drawing.Size(149, 27);
            this.txtempname.TabIndex = 3;
            // 
            // comgen
            // 
            this.comgen.FormattingEnabled = true;
            this.comgen.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comgen.Location = new System.Drawing.Point(679, 161);
            this.comgen.Margin = new System.Windows.Forms.Padding(4);
            this.comgen.Name = "comgen";
            this.comgen.Size = new System.Drawing.Size(150, 28);
            this.comgen.TabIndex = 4;
            // 
            // emppos
            // 
            this.emppos.FormattingEnabled = true;
            this.emppos.Items.AddRange(new object[] {
            "Senior Developer",
            "Junior Developer",
            "Associative Developer",
            "Tainnee",
            "Manager",
            "SystemSupervisior"});
            this.emppos.Location = new System.Drawing.Point(679, 300);
            this.emppos.Margin = new System.Windows.Forms.Padding(4);
            this.emppos.Name = "emppos";
            this.emppos.Size = new System.Drawing.Size(150, 28);
            this.emppos.TabIndex = 4;
            // 
            // empeducation
            // 
            this.empeducation.FormattingEnabled = true;
            this.empeducation.Items.AddRange(new object[] {
            "BTech /BE",
            "MTech",
            "BCA",
            "MCA",
            "BCOM",
            "MCOM"});
            this.empeducation.Location = new System.Drawing.Point(149, 441);
            this.empeducation.Margin = new System.Windows.Forms.Padding(4);
            this.empeducation.Name = "empeducation";
            this.empeducation.Size = new System.Drawing.Size(150, 28);
            this.empeducation.TabIndex = 4;
            // 
            // dateTimePickerdob
            // 
            this.dateTimePickerdob.Location = new System.Drawing.Point(387, 439);
            this.dateTimePickerdob.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerdob.Name = "dateTimePickerdob";
            this.dateTimePickerdob.Size = new System.Drawing.Size(190, 27);
            this.dateTimePickerdob.TabIndex = 5;
            this.dateTimePickerdob.ValueChanged += new System.EventHandler(this.dateTimePickerdob_ValueChanged);
            // 
            // empaddress
            // 
            this.empaddress.Location = new System.Drawing.Point(932, 355);
            this.empaddress.Margin = new System.Windows.Forms.Padding(4);
            this.empaddress.Multiline = true;
            this.empaddress.Name = "empaddress";
            this.empaddress.Size = new System.Drawing.Size(200, 111);
            this.empaddress.TabIndex = 3;
            // 
            // emplocation
            // 
            this.emplocation.FormattingEnabled = true;
            this.emplocation.Items.AddRange(new object[] {
            "Mumbai",
            "Pune",
            "Chennai",
            "Banglore",
            "Hyderabad",
            "GuruGav"});
            this.emplocation.Location = new System.Drawing.Point(679, 438);
            this.emplocation.Margin = new System.Windows.Forms.Padding(4);
            this.emplocation.Name = "emplocation";
            this.emplocation.Size = new System.Drawing.Size(150, 28);
            this.emplocation.TabIndex = 4;
            // 
            // btninsert
            // 
            this.btninsert.BackColor = System.Drawing.Color.Transparent;
            this.btninsert.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btninsert.BackgroundImage")));
            this.btninsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninsert.ForeColor = System.Drawing.Color.White;
            this.btninsert.Location = new System.Drawing.Point(1047, 485);
            this.btninsert.Margin = new System.Windows.Forms.Padding(4);
            this.btninsert.Name = "btninsert";
            this.btninsert.Size = new System.Drawing.Size(192, 62);
            this.btninsert.TabIndex = 7;
            this.btninsert.Text = "Add Employee Details";
            this.btninsert.UseVisualStyleBackColor = false;
            this.btninsert.Click += new System.EventHandler(this.btninsert_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(389, 110);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 20);
            this.label10.TabIndex = 0;
            this.label10.Text = "Password";
            // 
            // txtpass
            // 
            this.txtpass.Location = new System.Drawing.Point(387, 162);
            this.txtpass.Margin = new System.Windows.Forms.Padding(4);
            this.txtpass.Name = "txtpass";
            this.txtpass.Size = new System.Drawing.Size(175, 27);
            this.txtpass.TabIndex = 8;
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Red;
            this.btnexit.Location = new System.Drawing.Point(1227, 2);
            this.btnexit.Margin = new System.Windows.Forms.Padding(4);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(42, 32);
            this.btnexit.TabIndex = 9;
            this.btnexit.Text = "X";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // btnback
            // 
            this.btnback.Location = new System.Drawing.Point(0, 0);
            this.btnback.Margin = new System.Windows.Forms.Padding(4);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(75, 34);
            this.btnback.TabIndex = 10;
            this.btnback.Text = "<-";
            this.btnback.UseVisualStyleBackColor = true;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnfront
            // 
            this.btnfront.Location = new System.Drawing.Point(88, 0);
            this.btnfront.Margin = new System.Windows.Forms.Padding(4);
            this.btnfront.Name = "btnfront";
            this.btnfront.Size = new System.Drawing.Size(75, 34);
            this.btnfront.TabIndex = 10;
            this.btnfront.Text = "->";
            this.btnfront.UseVisualStyleBackColor = true;
            this.btnfront.Click += new System.EventHandler(this.btnfront_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.Location = new System.Drawing.Point(489, 18);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(268, 38);
            this.label11.TabIndex = 11;
            this.label11.Text = "Employee Details";
            // 
            // EmployeeInsert
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1272, 602);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btnfront);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.txtpass);
            this.Controls.Add(this.btninsert);
            this.Controls.Add(this.dateTimePickerdob);
            this.Controls.Add(this.emplocation);
            this.Controls.Add(this.empeducation);
            this.Controls.Add(this.emppos);
            this.Controls.Add(this.comgen);
            this.Controls.Add(this.txtempname);
            this.Controls.Add(this.empaddress);
            this.Controls.Add(this.txtphone);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lblempid);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "EmployeeInsert";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EmployeeInsert";
            this.Load += new System.EventHandler(this.EmployeeInsert_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblempid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtphone;
        private System.Windows.Forms.TextBox txtempname;
        private System.Windows.Forms.ComboBox comgen;
        private System.Windows.Forms.ComboBox emppos;
        private System.Windows.Forms.ComboBox empeducation;
        private System.Windows.Forms.DateTimePicker dateTimePickerdob;
        private System.Windows.Forms.TextBox empaddress;
        private System.Windows.Forms.ComboBox emplocation;
        private System.Windows.Forms.Button btninsert;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtpass;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnfront;
        private System.Windows.Forms.Label label11;
    }
}