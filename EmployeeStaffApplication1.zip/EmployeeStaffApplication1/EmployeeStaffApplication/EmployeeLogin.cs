﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeStaffApplication
{
    public partial class EmployeeLogin : Form
    {
        public static string empid ;
        SqlConnection conn;
        public EmployeeLogin()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["emp"].ConnectionString);
        }

        public  string EmmpIDS()
        {
            return txtemp.Text.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            empid = txtemp.Text.ToString();
            try
            {
                conn.Open();
                string sql = "select *from EmployeeDetails where Empid= '" + txtemp.Text + "'and EmpPass='" + txtemppass.Text + "'";

                //  SqlDataAdapter sda = new SqlDataAdapter(sql, conn);
                // DataTable dt = new DataTable();
                //sda.Fill(dt);
                //if (dt.Rows.Count==1)
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    MessageBox.Show("SUCESSFULLY LOGIN");
                    EmpInterface s = new EmpInterface();
                    s.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("INVALID EMPLOYEE ID AND PASSWORD !!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                
            }
            catch (Exception)
            {
                MessageBox.Show("EMPLOYEE ID SHOULD BE IN NUMBERS ONLE!!");
            }

            conn.Close();

            clearall();
        }
        private void clearall()
        {
            txtemp.Text = "";
            txtemppass.Text = "";
        }
        private void EmployeeLogin_Load(object sender, EventArgs e)
        {

        }

        private void btnunhide_Click(object sender, EventArgs e)
        {
            if (txtemppass.PasswordChar == '\0')
            {
                btnunhide.BringToFront();
                txtemppass.PasswordChar = '*';
            }
           
        }

        private void btnhide_Click(object sender, EventArgs e)
        {
            if (txtemppass.PasswordChar == '*')
            {
                btnhide.BringToFront();
                txtemppass.PasswordChar = '\0';
            }

        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            DashBoard dashboard = new DashBoard();
            dashboard.Show();
            this.Hide();
        }
    }
}