﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeStaffApplication
{
    public partial class EmployeeInsert : Form
    {
        SqlConnection conn;
        public EmployeeInsert()
        { 
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["emp"].ConnectionString);
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            EmpPoco emp = new EmpPoco();
            try
            {
                string query = "select max(Empid) from EmployeeDetails";
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                emp.EmpId = (int)cmd.ExecuteScalar() + 1;
                lblempid.Text = emp.EmpId.ToString();
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
            try
            {
                conn.Open();
                string query = "insert into EmployeeDetails values('" + lblempid.Text + "','" + txtempname.Text + "','" + txtphone.Text + "','" + comgen.SelectedItem.ToString() + "','" + emppos.SelectedItem.ToString() + "','" + empeducation.SelectedItem.ToString() + "','" + dateTimePickerdob.Text + "','" + empaddress.Text + "','"+emplocation.SelectedItem.ToString()+"','"+txtpass.Text+"')";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee successfully Added ");
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
            Clear();
        }

        private void EmployeeInsert_Load(object sender, EventArgs e)
        {

        }
        private void Clear()
        {
         
            txtempname.Text = "";
            txtphone.Text = "";
            comgen.Text = "";
            emppos.Text = "";
            empeducation.Text = "";
            dateTimePickerdob.Text = "";
            empaddress.Text = "";
            emplocation.Text = "";
            txtpass.Text = "";
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            AdminLogin l = new AdminLogin();
            l.Show();
            this.Hide();
        }

        private void btnfront_Click(object sender, EventArgs e)
        {
            EmployeeDisplay d = new EmployeeDisplay();
            d.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePickerdob_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
